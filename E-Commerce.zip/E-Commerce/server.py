import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dependencies import seed_demo_data
from routers import products, cart, orders, admin

app = FastAPI(
    title="E-Commerce Order Engine",
    description="""
## Distributed E-Commerce Backend API

Full order lifecycle engine with:
- **Product management** & real-time stock reservation
- **Multi-user cart** with coupon & discount engine
- **Atomic order placement** with payment simulation
- **Transaction rollback** on failure
- **Order state machine** (CREATED → PAID → SHIPPED → DELIVERED)
- **Concurrency simulation** with per-product locking
- **Fraud detection** & audit logging

### Quick Start
1. `GET /products/` — browse demo products (auto-loaded on startup)
2. `POST /cart/{user_id}/items` — add to cart
3. `POST /cart/{user_id}/coupon` — apply SAVE10 or FLAT200
4. `POST /orders/{user_id}` — place order
5. `PATCH /orders/{order_id}/advance` — ship & deliver
6. `POST /admin/simulate-concurrency` — test locking
    """,
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(products.router)
app.include_router(cart.router)
app.include_router(orders.router)
app.include_router(admin.router)


@app.on_event("startup")
def on_startup():
    seed_demo_data()
    print("\n  ✓ Demo data loaded.")
    print("  ✓ Swagger UI: http://127.0.0.1:8000/docs")
    print("  ✓ ReDoc:      http://127.0.0.1:8000/redoc\n")


@app.get("/", tags=["Health"])
def root():
    return {
        "status": "running",
        "docs":   "http://127.0.0.1:8000/docs",
        "redoc":  "http://127.0.0.1:8000/redoc",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)