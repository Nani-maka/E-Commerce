from datetime import datetime
from typing import List


class AuditLogger:
    def __init__(self):
        self._logs: List[str] = []

    def log(self, message: str):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        self._logs.append(entry)

    def get_logs(self) -> List[str]:
        return list(self._logs)