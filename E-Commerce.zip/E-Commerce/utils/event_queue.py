from collections import deque
from typing import Callable, Dict, List
from utils.audit_logger import AuditLogger


class EventQueue:
    def __init__(self, logger: AuditLogger):
        self._queue: deque = deque()
        self._handlers: Dict[str, List[Callable]] = {}
        self.logger = logger

    def subscribe(self, event_type: str, handler: Callable):
        self._handlers.setdefault(event_type, []).append(handler)

    def publish(self, event_type: str, payload: dict):
        self._queue.append((event_type, payload))
        self._process()

    def _process(self):
        while self._queue:
            event_type, payload = self._queue.popleft()
            self.logger.log(f"EVENT: {event_type} -> {payload}")
            for handler in self._handlers.get(event_type, []):
                try:
                    handler(payload)
                except Exception as e:
                    self.logger.log(f"EVENT_HANDLER_FAILED: {event_type} - {e}")
                    self._queue.clear()
                    return