import threading
from services.product_service import ProductService
from services.cart_service import CartService
from utils.audit_logger import AuditLogger


def simulate_concurrent_users(
    product_service: ProductService,
    cart_service: CartService,
    logger: AuditLogger,
    product_id: str,
    users: list,
    qty_each: int,
) -> dict:
    results = {}
    product = product_service.get_product(product_id)
    if not product:
        return {"error": "Product not found."}

    def try_add(user_id):
        ok, msg = cart_service.add_item(user_id, product_id, qty_each)
        results[user_id] = {"success": ok, "message": msg}

    threads = [threading.Thread(target=try_add, args=(u,)) for u in users]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    logger.log(f"CONCURRENCY_SIM: product={product_id}, users={users}, qty={qty_each}")
    return results