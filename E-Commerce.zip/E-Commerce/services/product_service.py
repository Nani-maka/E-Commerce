from typing import Dict, List, Optional
from models.models import Product
from utils.audit_logger import AuditLogger
from utils.lock_manager import LockManager

LOW_STOCK_THRESHOLD = 5


class ProductService:
    def __init__(self, logger: AuditLogger, lock_manager: LockManager):
        self._products: Dict[str, Product] = {}
        self.logger = logger
        self.lock_manager = lock_manager

    def add_product(self, product_id: str, name: str, price: float, stock: int):
        if product_id in self._products:
            return False, f"Product ID '{product_id}' already exists."
        if stock < 0:
            return False, "Stock cannot be negative."
        if price <= 0:
            return False, "Price must be positive."
        self._products[product_id] = Product(product_id=product_id, name=name, price=price, stock=stock)
        self.logger.log(f"PRODUCT_ADDED: {product_id} - {name}, stock={stock}, price={price}")
        return True, f"Product '{name}' added successfully."

    def update_stock(self, product_id: str, new_stock: int):
        if product_id not in self._products:
            return False, "Product not found."
        if new_stock < 0:
            return False, "Stock cannot be negative."
        self._products[product_id].stock = new_stock
        self.logger.log(f"STOCK_UPDATED: {product_id} -> {new_stock}")
        return True, f"Stock updated to {new_stock}."

    def get_product(self, product_id: str) -> Optional[Product]:
        return self._products.get(product_id)

    def get_all_products(self) -> List[Product]:
        return list(self._products.values())

    def get_low_stock_products(self) -> List[Product]:
        return [p for p in self._products.values() if p.stock <= LOW_STOCK_THRESHOLD]

    def reserve_stock(self, product_id: str, qty: int):
        lock = self.lock_manager.get_lock(product_id)
        with lock:
            product = self._products.get(product_id)
            if not product:
                return False, "Product not found."
            if product.available_stock < qty:
                return False, f"Insufficient stock. Available: {product.available_stock}"
            product.reserved += qty
            self.logger.log(f"STOCK_RESERVED: {product_id}, qty={qty}")
            return True, "Stock reserved."

    def release_stock(self, product_id: str, qty: int):
        lock = self.lock_manager.get_lock(product_id)
        with lock:
            product = self._products.get(product_id)
            if product:
                product.reserved = max(0, product.reserved - qty)
                self.logger.log(f"STOCK_RELEASED: {product_id}, qty={qty}")

    def confirm_stock_deduction(self, product_id: str, qty: int):
        lock = self.lock_manager.get_lock(product_id)
        with lock:
            product = self._products.get(product_id)
            if not product:
                return False, "Product not found."
            product.reserved = max(0, product.reserved - qty)
            product.stock -= qty
            self.logger.log(f"STOCK_DEDUCTED: {product_id}, qty={qty}, remaining={product.stock}")
            return True, "OK"

    def restore_stock(self, product_id: str, qty: int):
        lock = self.lock_manager.get_lock(product_id)
        with lock:
            product = self._products.get(product_id)
            if product:
                product.stock += qty
                self.logger.log(f"STOCK_RESTORED: {product_id}, qty={qty}")