from typing import Dict
from models.models import Cart, CartItem
from services.product_service import ProductService
from utils.audit_logger import AuditLogger

VALID_COUPONS = {
    "SAVE10":  {"type": "percent", "value": 10},
    "FLAT200": {"type": "flat",    "value": 200},
}


class CartService:
    def __init__(self, product_service: ProductService, logger: AuditLogger):
        self._carts: Dict[str, Cart] = {}
        self.product_service = product_service
        self.logger = logger

    def get_or_create_cart(self, user_id: str) -> Cart:
        if user_id not in self._carts:
            self._carts[user_id] = Cart(user_id=user_id)
        return self._carts[user_id]

    def add_item(self, user_id: str, product_id: str, qty: int):
        product = self.product_service.get_product(product_id)
        if not product:
            return False, "Product not found."
        if qty <= 0:
            return False, "Quantity must be positive."
        if product.stock == 0:
            return False, "Product is out of stock."

        cart = self.get_or_create_cart(user_id)
        existing_qty = cart.items[product_id].quantity if product_id in cart.items else 0
        additional_qty = qty - existing_qty if product_id in cart.items else qty

        if additional_qty <= 0 and product_id in cart.items:
            release_qty = existing_qty - qty
            self.product_service.release_stock(product_id, release_qty)
            cart.items[product_id].quantity = qty
            self.logger.log(f"CART_UPDATED: {user_id} updated {product_id} qty={qty}")
            return True, f"Quantity updated to {qty}."

        ok, msg = self.product_service.reserve_stock(product_id, additional_qty)
        if not ok:
            return False, msg

        if product_id in cart.items:
            cart.items[product_id].quantity = qty
        else:
            cart.items[product_id] = CartItem(
                product_id=product_id,
                quantity=qty,
                price_at_add=product.price,
            )
        self.logger.log(f"CART_ADD: {user_id} added {product_id} qty={qty}")
        return True, f"Added {qty}x {product.name} to cart."

    def remove_item(self, user_id: str, product_id: str):
        cart = self._carts.get(user_id)
        if not cart or product_id not in cart.items:
            return False, "Item not in cart."
        qty = cart.items[product_id].quantity
        self.product_service.release_stock(product_id, qty)
        del cart.items[product_id]
        self.logger.log(f"CART_REMOVE: {user_id} removed {product_id}")
        return True, "Item removed."

    def apply_coupon(self, user_id: str, coupon: str):
        cart = self.get_or_create_cart(user_id)
        coupon = coupon.upper()
        if coupon not in VALID_COUPONS:
            return False, "Invalid coupon. Valid codes: SAVE10, FLAT200"
        cart.coupon = coupon
        self.logger.log(f"COUPON_APPLIED: {user_id} applied {coupon}")
        return True, f"Coupon '{coupon}' applied!"

    def calculate_total(self, user_id: str) -> dict:
        cart = self.get_or_create_cart(user_id)
        subtotal = cart.subtotal()
        discount = 0.0

        if subtotal > 1000:
            discount += subtotal * 0.10

        for item in cart.items.values():
            if item.quantity > 3:
                discount += item.price_at_add * item.quantity * 0.05

        if cart.coupon:
            c = VALID_COUPONS[cart.coupon]
            if c["type"] == "percent":
                discount += subtotal * c["value"] / 100
            elif c["type"] == "flat":
                discount += min(c["value"], subtotal)

        total = max(0.0, subtotal - discount)
        return {
            "subtotal": round(subtotal, 2),
            "discount": round(discount, 2),
            "total": round(total, 2),
        }

    def clear_cart(self, user_id: str):
        self._carts[user_id] = Cart(user_id=user_id)