import random
from utils.audit_logger import AuditLogger


class PaymentService:
    def __init__(self, logger: AuditLogger):
        self.logger = logger
        self.failure_mode = False
        self._failure_rate = 0.3

    def set_failure_mode(self, enabled: bool):
        self.failure_mode = enabled
        self.logger.log(f"FAILURE_INJECTION: {'ENABLED' if enabled else 'DISABLED'}")

    def process_payment(self, order_id: str, amount: float):
        if self.failure_mode:
            self.logger.log(f"PAYMENT_FORCED_FAIL: order={order_id}")
            return False, "Payment failed (failure injection active)."
        if random.random() < self._failure_rate:
            self.logger.log(f"PAYMENT_FAILED: order={order_id}")
            return False, "Payment declined by gateway (simulated)."
        self.logger.log(f"PAYMENT_SUCCESS: order={order_id}, amount={amount}")
        return True, "Payment successful."