import uuid
import time
import threading
from typing import Dict, List, Optional
from collections import defaultdict

from models.models import Order, OrderItem, OrderStatus
from services.product_service import ProductService
from services.cart_service import CartService
from services.payment_service import PaymentService
from utils.audit_logger import AuditLogger
from utils.event_queue import EventQueue

FRAUD_ORDER_COUNT_THRESHOLD = 3
FRAUD_ORDER_WINDOW_SECONDS  = 60
FRAUD_HIGH_VALUE_THRESHOLD  = 10000


class OrderService:
    def __init__(self, product_service, cart_service, payment_service, logger, event_queue):
        self._orders: Dict[str, Order] = {}
        self._idempotency_keys: Dict[str, str] = {}
        self._user_order_times: Dict[str, List[float]] = defaultdict(list)
        self._flagged_users: set = set()
        self._reservation_timers: Dict[str, threading.Timer] = {}

        self.product_service = product_service
        self.cart_service    = cart_service
        self.payment_service = payment_service
        self.logger          = logger
        self.event_queue     = event_queue

    def _idempotency_key(self, user_id: str) -> str:
        cart = self.cart_service.get_or_create_cart(user_id)
        items_str = ",".join(sorted(f"{pid}:{i.quantity}" for pid, i in cart.items.items()))
        return f"{user_id}:{items_str}"

    def _check_fraud(self, user_id: str, total: float):
        now = time.time()
        self._user_order_times[user_id] = [
            t for t in self._user_order_times[user_id]
            if now - t < FRAUD_ORDER_WINDOW_SECONDS
        ]
        count = len(self._user_order_times[user_id])
        if count >= FRAUD_ORDER_COUNT_THRESHOLD:
            self._flagged_users.add(user_id)
            self.logger.log(f"FRAUD_ALERT: {user_id} - {count} orders in 60s")
            return True, f"Fraud alert: {count} orders placed in last 60s."
        if total >= FRAUD_HIGH_VALUE_THRESHOLD:
            self._flagged_users.add(user_id)
            self.logger.log(f"FRAUD_ALERT: {user_id} - high value order {total}")
            return True, f"Fraud alert: High-value order flagged."
        return False, ""

    def place_order(self, user_id: str):
        cart = self.cart_service.get_or_create_cart(user_id)
        if not cart.items:
            return False, "Cart is empty.", None

        idem_key = self._idempotency_key(user_id)
        if idem_key in self._idempotency_keys:
            existing = self._orders.get(self._idempotency_keys[idem_key])
            if existing and existing.status not in (OrderStatus.FAILED, OrderStatus.CANCELLED):
                return False, f"Duplicate order detected. Existing: {existing.order_id}", existing

        totals   = self.cart_service.calculate_total(user_id)
        subtotal = totals["subtotal"]
        discount = totals["discount"]
        total    = totals["total"]

        is_fraud, fraud_msg = self._check_fraud(user_id, total)

        order_id = f"ORD-{uuid.uuid4().hex[:8].upper()}"
        order_items = [
            OrderItem(
                product_id=pid,
                product_name=self.product_service.get_product(pid).name,
                quantity=item.quantity,
                unit_price=item.price_at_add,
            )
            for pid, item in cart.items.items()
        ]

        order = Order(
            order_id=order_id, user_id=user_id, items=order_items,
            subtotal=subtotal, discount=discount, total=total,
            status=OrderStatus.CREATED, coupon=cart.coupon,
            idempotency_key=idem_key,
        )
        self._orders[order_id] = order
        self._idempotency_keys[idem_key] = order_id
        self.logger.log(f"ORDER_CREATED: {order_id}, user={user_id}, total={total}")
        self.event_queue.publish("ORDER_CREATED", {"order_id": order_id})
        self._transition(order, OrderStatus.PENDING_PAYMENT)

        paid, pay_msg = self.payment_service.process_payment(order_id, total)
        if not paid:
            self._rollback(order, cart.items)
            return False, pay_msg, order

        for pid, item in cart.items.items():
            self.product_service.confirm_stock_deduction(pid, item.quantity)

        self._transition(order, OrderStatus.PAID)
        self.cart_service.clear_cart(user_id)
        self._user_order_times[user_id].append(time.time())
        self.event_queue.publish("PAYMENT_SUCCESS", {"order_id": order_id, "amount": total})
        self.event_queue.publish("INVENTORY_UPDATED", {"order_id": order_id})

        fraud_note = fraud_msg if is_fraud else None
        return True, "Order placed successfully.", order, fraud_note

    def _rollback(self, order: Order, cart_items):
        self.logger.log(f"ROLLBACK: {order.order_id}")
        for pid, item in cart_items.items():
            self.product_service.release_stock(pid, item.quantity)
        self._transition(order, OrderStatus.FAILED)

    def _transition(self, order: Order, new_status: OrderStatus) -> bool:
        if not order.can_transition_to(new_status):
            self.logger.log(f"INVALID_TRANSITION: {order.order_id} {order.status} -> {new_status}")
            return False
        order.status = new_status
        self.logger.log(f"ORDER_STATUS: {order.order_id} -> {new_status.value}")
        return True

    def advance_order_status(self, order_id: str):
        order = self._orders.get(order_id)
        if not order:
            return False, "Order not found."
        next_map = {
            OrderStatus.PAID:    OrderStatus.SHIPPED,
            OrderStatus.SHIPPED: OrderStatus.DELIVERED,
        }
        next_status = next_map.get(order.status)
        if not next_status:
            return False, f"Cannot advance from '{order.status.value}'."
        if self._transition(order, next_status):
            return True, f"Order is now {next_status.value}."
        return False, "Transition not allowed."

    def cancel_order(self, order_id: str):
        order = self._orders.get(order_id)
        if not order:
            return False, "Order not found."
        if order.status == OrderStatus.CANCELLED:
            return False, "Order is already cancelled."
        if not order.can_transition_to(OrderStatus.CANCELLED):
            return False, f"Cannot cancel order in '{order.status.value}' state."
        for item in order.items:
            self.product_service.restore_stock(item.product_id, item.quantity - item.returned_qty)
        self._transition(order, OrderStatus.CANCELLED)
        return True, f"Order {order_id} cancelled. Stock restored."

    def return_items(self, order_id: str, product_id: str, qty: int):
        order = self._orders.get(order_id)
        if not order:
            return False, "Order not found."
        if order.status != OrderStatus.DELIVERED:
            return False, "Only delivered orders can be returned."
        for item in order.items:
            if item.product_id == product_id:
                returnable = item.quantity - item.returned_qty
                if qty > returnable:
                    return False, f"Can only return up to {returnable} units."
                item.returned_qty += qty
                refund = qty * item.unit_price
                order.total -= refund
                self.product_service.restore_stock(product_id, qty)
                self.logger.log(f"RETURN: {order_id}, {qty}x {product_id}, refund={refund}")
                return True, f"Refund of Rs{refund:.2f} processed."
        return False, f"Product {product_id} not in order."

    def schedule_reservation_expiry(self, user_id: str, expiry_seconds: int = 300):
        if user_id in self._reservation_timers:
            self._reservation_timers[user_id].cancel()

        def expire():
            cart = self.cart_service.get_or_create_cart(user_id)
            if cart.items:
                for pid, item in list(cart.items.items()):
                    self.product_service.release_stock(pid, item.quantity)
                self.cart_service.clear_cart(user_id)
                self.logger.log(f"RESERVATION_EXPIRED: {user_id}")

        timer = threading.Timer(expiry_seconds, expire)
        timer.daemon = True
        timer.start()
        self._reservation_timers[user_id] = timer

    def get_order(self, order_id: str): return self._orders.get(order_id)
    def get_all_orders(self): return list(self._orders.values())
    def get_orders_by_status(self, status): return [o for o in self._orders.values() if o.status == status]
    def get_flagged_users(self): return list(self._flagged_users)