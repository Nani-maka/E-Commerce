import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.audit_logger  import AuditLogger
from utils.lock_manager  import LockManager
from utils.event_queue   import EventQueue
from services.product_service  import ProductService
from services.cart_service     import CartService
from services.payment_service  import PaymentService
from services.order_service    import OrderService

logger        = AuditLogger()
lock_manager  = LockManager()
event_queue   = EventQueue(logger)
product_svc   = ProductService(logger, lock_manager)
cart_svc      = CartService(product_svc, logger)
payment_svc   = PaymentService(logger)
order_svc     = OrderService(product_svc, cart_svc, payment_svc, logger, event_queue)


def seed_demo_data():
    demos = [
        ("P001", "Laptop Pro 15",      75000.0, 10),
        ("P002", "Wireless Earbuds",    2500.0,  3),
        ("P003", "USB-C Hub",            999.0, 20),
        ("P004", "Mechanical Keyboard",  4500.0,  0),
        ("P005", "Webcam HD",            1800.0,  5),
    ]
    for pid, name, price, stock in demos:
        product_svc.add_product(pid, name, price, stock)