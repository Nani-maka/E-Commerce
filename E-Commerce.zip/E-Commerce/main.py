import sys
import os

_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from models.models import OrderStatus
from services.product_service import ProductService
from services.cart_service import CartService
from services.order_service import OrderService
from services.payment_service import PaymentService
from services.concurrency_service import simulate_concurrent_users
from utils.audit_logger import AuditLogger
from utils.event_queue import EventQueue
from utils.lock_manager import LockManager


def ok(msg):   print(f"  [OK] {msg}")
def err(msg):  print(f"  [ERR] {msg}")
def info(msg): print(f"  [INFO] {msg}")


def build_services():
    logger       = AuditLogger()
    lock_manager = LockManager()
    event_queue  = EventQueue(logger)
    product_svc  = ProductService(logger, lock_manager)
    cart_svc     = CartService(product_svc, logger)
    payment_svc  = PaymentService(logger)
    order_svc    = OrderService(product_svc, cart_svc, payment_svc, logger, event_queue)
    return logger, product_svc, cart_svc, payment_svc, order_svc


def seed_demo_data(product_svc):
    demos = [
        ("P001", "Laptop Pro 15",     75000.0, 10),
        ("P002", "Wireless Earbuds",   2500.0,  3),
        ("P003", "USB-C Hub",           999.0, 20),
        ("P004", "Mechanical Keyboard", 4500.0,  0),
        ("P005", "Webcam HD",           1800.0,  5),
    ]
    for pid, name, price, stock in demos:
        product_svc.add_product(pid, name, price, stock)
    print(f"  Demo data loaded: {len(demos)} products.")


def prompt(label, default=None):
    suffix = f" [{default}]" if default is not None else ""
    val = input(f"  {label}{suffix}: ").strip()
    return val if val else str(default) if default is not None else val

def prompt_int(label, default=None):
    while True:
        try:
            return int(prompt(label, default))
        except ValueError:
            err("Please enter a valid integer.")

def prompt_float(label, default=None):
    while True:
        try:
            return float(prompt(label, default))
        except ValueError:
            err("Please enter a valid number.")


def menu_add_product(product_svc):
    print("\n  -- Add Product --")
    pid   = prompt("Product ID")
    name  = prompt("Product Name")
    price = prompt_float("Price")
    stock = prompt_int("Initial Stock")
    success, msg = product_svc.add_product(pid, name, price, stock)
    ok(msg) if success else err(msg)

def menu_view_products(product_svc):
    print("\n  -- Product Catalog --")
    product_svc.print_all_products()

def menu_add_to_cart(cart_svc, order_svc):
    print("\n  -- Add to Cart --")
    user = prompt("User ID", "user1")
    pid  = prompt("Product ID")
    qty  = prompt_int("Quantity", 1)
    success, msg = cart_svc.add_item(user, pid, qty)
    ok(msg) if success else err(msg)
    if success:
        order_svc.schedule_reservation_expiry(user, expiry_seconds=300)
        info("Cart reservation expires in 5 minutes if order not placed.")

def menu_remove_from_cart(cart_svc):
    print("\n  -- Remove from Cart --")
    user = prompt("User ID", "user1")
    pid  = prompt("Product ID")
    success, msg = cart_svc.remove_item(user, pid)
    ok(msg) if success else err(msg)

def menu_view_cart(cart_svc):
    print("\n  -- View Cart --")
    user = prompt("User ID", "user1")
    cart_svc.print_cart(user)

def menu_apply_coupon(cart_svc):
    print("\n  -- Apply Coupon --")
    info("Available: SAVE10 (10% off) | FLAT200 (Rs200 off)")
    user   = prompt("User ID", "user1")
    coupon = prompt("Coupon Code")
    success, msg = cart_svc.apply_coupon(user, coupon)
    ok(msg) if success else err(msg)

def menu_place_order(order_svc):
    print("\n  -- Place Order --")
    user = prompt("User ID", "user1")
    success, msg, order = order_svc.place_order(user)
    ok(msg) if success else err(msg)
    if order:
        order_svc.print_order_detail(order.order_id)

def menu_cancel_order(order_svc):
    print("\n  -- Cancel Order --")
    oid = prompt("Order ID")
    success, msg = order_svc.cancel_order(oid)
    ok(msg) if success else err(msg)

def menu_view_orders(order_svc):
    print("\n  -- View Orders --")
    print("  Filter: [1] All  [2] Completed  [3] Cancelled  [4] Failed  [5] By ID")
    choice = prompt("Choice", "1")
    if choice == "1":
        order_svc.print_orders()
    elif choice == "2":
        order_svc.print_orders(order_svc.get_orders_by_status(OrderStatus.DELIVERED))
    elif choice == "3":
        order_svc.print_orders(order_svc.get_orders_by_status(OrderStatus.CANCELLED))
    elif choice == "4":
        order_svc.print_orders(order_svc.get_orders_by_status(OrderStatus.FAILED))
    elif choice == "5":
        oid = prompt("Order ID")
        order_svc.print_order_detail(oid)

def menu_low_stock_alert(product_svc):
    print("\n  -- Low Stock Alert --")
    low = product_svc.get_low_stock_products()
    if not low:
        ok("All products have healthy stock levels.")
        return
    print(f"\n  WARNING: {len(low)} product(s) with low/zero stock:")
    print(f"  {'ID':<12} {'Name':<22} {'Stock':>8}")
    print(f"  {'-'*44}")
    for p in low:
        status = "OUT OF STOCK" if p.stock == 0 else str(p.stock)
        print(f"  {p.product_id:<12} {p.name:<22} {status:>8}")

def menu_return_product(order_svc):
    print("\n  -- Return Product --")
    oid = prompt("Order ID")
    pid = prompt("Product ID to return")
    qty = prompt_int("Quantity to return", 1)
    success, msg = order_svc.return_items(oid, pid, qty)
    ok(msg) if success else err(msg)

def menu_simulate_concurrent(product_svc, cart_svc, logger):
    print("\n  -- Simulate Concurrent Users --")
    pid      = prompt("Product ID", "P001")
    n_users  = prompt_int("Number of concurrent users", 3)
    qty_each = prompt_int("Quantity each user wants", 5)
    users    = [f"sim_user_{i+1}" for i in range(n_users)]
    simulate_concurrent_users(product_svc, cart_svc, logger, pid, users, qty_each)

def menu_view_logs(logger):
    print("\n  -- Audit Logs --")
    logger.print_all()

def menu_failure_mode(payment_svc):
    print("\n  -- Failure Injection --")
    info("[1] Enable forced failure  [2] Disable")
    choice = prompt("Choice", "1")
    if choice == "1":
        payment_svc.set_failure_mode(True)
        ok("Forced payment failure ENABLED.")
    elif choice == "2":
        payment_svc.set_failure_mode(False)
        ok("Failure injection DISABLED.")

def menu_advance_order(order_svc):
    print("\n  -- Advance Order Status --")
    oid = prompt("Order ID")
    success, msg = order_svc.advance_order_status(oid)
    ok(msg) if success else err(msg)

def menu_update_stock(product_svc):
    print("\n  -- Update Stock --")
    pid   = prompt("Product ID")
    stock = prompt_int("New Stock")
    success, msg = product_svc.update_stock(pid, stock)
    ok(msg) if success else err(msg)


MENU = """
============================================
   E-Commerce Order Engine  - CLI
============================================
  Product:  1.Add  2.View  U.UpdateStock  L.LowStock
  Cart:     3.AddToCart  4.Remove  5.ViewCart  6.Coupon
  Orders:   7.PlaceOrder  8.Cancel  9.ViewOrders
            11.Return  A.AdvanceStatus
  Simulate: 12.ConcurrentUsers  13.Logs  14.FailureMode
  0. Exit
--------------------------------------------"""


def run():
    logger, product_svc, cart_svc, payment_svc, order_svc = build_services()
    print("\n  Initializing E-Commerce Order Engine...")
    load = input("  Load demo data? (y/n) [y]: ").strip().lower()
    if load in ("y", "yes", ""):
        seed_demo_data(product_svc)

    while True:
        print(MENU)
        choice = input("  Enter choice: ").strip().lower()
        try:
            if   choice == "1":  menu_add_product(product_svc)
            elif choice == "2":  menu_view_products(product_svc)
            elif choice == "3":  menu_add_to_cart(cart_svc, order_svc)
            elif choice == "4":  menu_remove_from_cart(cart_svc)
            elif choice == "5":  menu_view_cart(cart_svc)
            elif choice == "6":  menu_apply_coupon(cart_svc)
            elif choice == "7":  menu_place_order(order_svc)
            elif choice == "8":  menu_cancel_order(order_svc)
            elif choice == "9":  menu_view_orders(order_svc)
            elif choice == "10": menu_low_stock_alert(product_svc)
            elif choice == "11": menu_return_product(order_svc)
            elif choice == "12": menu_simulate_concurrent(product_svc, cart_svc, logger)
            elif choice == "13": menu_view_logs(logger)
            elif choice == "14": menu_failure_mode(payment_svc)
            elif choice == "a":  menu_advance_order(order_svc)
            elif choice == "u":  menu_update_stock(product_svc)
            elif choice == "l":  menu_low_stock_alert(product_svc)
            elif choice == "0":
                print("\n  Goodbye!\n")
                break
            else:
                err("Invalid choice.")
        except KeyboardInterrupt:
            print("\n  Interrupted. Returning to menu.")
        except Exception as e:
            err(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()

        input("\n  Press Enter to continue...")


if __name__ == "__main__":
    run()