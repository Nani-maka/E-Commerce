from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from dependencies import cart_svc, order_svc

router = APIRouter(prefix="/cart", tags=["Cart"])


class AddItemRequest(BaseModel):
    product_id: str
    quantity: int


class CouponRequest(BaseModel):
    coupon: str


@router.post("/{user_id}/items", summary="Add item to cart")
def add_to_cart(user_id: str, req: AddItemRequest):
    ok, msg = cart_svc.add_item(user_id, req.product_id, req.quantity)
    if not ok:
        raise HTTPException(400, detail=msg)
    order_svc.schedule_reservation_expiry(user_id, expiry_seconds=300)
    return {"message": msg}


@router.delete("/{user_id}/items/{product_id}", summary="Remove item from cart")
def remove_from_cart(user_id: str, product_id: str):
    ok, msg = cart_svc.remove_item(user_id, product_id)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}


@router.get("/{user_id}", summary="View cart with totals and discounts")
def view_cart(user_id: str):
    cart   = cart_svc.get_or_create_cart(user_id)
    totals = cart_svc.calculate_total(user_id)
    items  = [
        {
            "product_id": item.product_id,
            "quantity": item.quantity,
            "unit_price": item.price_at_add,
            "line_total": round(item.price_at_add * item.quantity, 2),
        }
        for item in cart.items.values()
    ]
    return {"user_id": user_id, "items": items, **totals, "coupon": cart.coupon}


@router.post("/{user_id}/coupon", summary="Apply coupon code (SAVE10 or FLAT200)")
def apply_coupon(user_id: str, req: CouponRequest):
    ok, msg = cart_svc.apply_coupon(user_id, req.coupon)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}


@router.delete("/{user_id}", summary="Clear entire cart")
def clear_cart(user_id: str):
    cart_svc.clear_cart(user_id)
    return {"message": f"Cart cleared for {user_id}."}