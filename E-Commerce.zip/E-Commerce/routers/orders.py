from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from dependencies import order_svc
from models.models import OrderStatus

router = APIRouter(prefix="/orders", tags=["Orders"])


class ReturnRequest(BaseModel):
    product_id: str
    quantity: int


def order_to_dict(order):
    return {
        "order_id":  order.order_id,
        "user_id":   order.user_id,
        "status":    order.status.value,
        "subtotal":  order.subtotal,
        "discount":  order.discount,
        "total":     order.total,
        "coupon":    order.coupon,
        "items": [
            {
                "product_id":   i.product_id,
                "product_name": i.product_name,
                "quantity":     i.quantity,
                "unit_price":   i.unit_price,
                "returned_qty": i.returned_qty,
                "line_total":   i.total,
            }
            for i in order.items
        ],
    }


@router.post("/{user_id}", summary="Place order from cart")
def place_order(user_id: str):
    result = order_svc.place_order(user_id)
    success, msg, order = result[0], result[1], result[2]
    fraud_note = result[3] if len(result) == 4 else None

    if not success:
        raise HTTPException(
            status_code=402 if order else 400,
            detail={"message": msg, "order": order_to_dict(order) if order else None},
        )
    resp = {"message": msg, "order": order_to_dict(order)}
    if fraud_note:
        resp["fraud_warning"] = fraud_note
    return resp


@router.get("/", summary="View all orders (optional ?status= filter)")
def get_all_orders(status: Optional[str] = None):
    if status:
        try:
            s = OrderStatus(status.upper())
        except ValueError:
            raise HTTPException(400, detail=f"Invalid status '{status}'. Valid: CREATED, PENDING_PAYMENT, PAID, SHIPPED, DELIVERED, FAILED, CANCELLED")
        return [order_to_dict(o) for o in order_svc.get_orders_by_status(s)]
    return [order_to_dict(o) for o in order_svc.get_all_orders()]


@router.get("/{order_id}", summary="Get order by ID")
def get_order(order_id: str):
    order = order_svc.get_order(order_id)
    if not order:
        raise HTTPException(404, detail="Order not found.")
    return order_to_dict(order)


@router.patch("/{order_id}/cancel", summary="Cancel an order")
def cancel_order(order_id: str):
    ok, msg = order_svc.cancel_order(order_id)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}


@router.patch("/{order_id}/advance", summary="Advance order: PAID → SHIPPED → DELIVERED")
def advance_order(order_id: str):
    ok, msg = order_svc.advance_order_status(order_id)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}


@router.post("/{order_id}/return", summary="Return items from a delivered order")
def return_items(order_id: str, req: ReturnRequest):
    ok, msg = order_svc.return_items(order_id, req.product_id, req.quantity)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}