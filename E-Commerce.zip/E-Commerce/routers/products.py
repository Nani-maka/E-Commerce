from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from dependencies import product_svc

router = APIRouter(prefix="/products", tags=["Products"])


class AddProductRequest(BaseModel):
    product_id: str
    name: str
    price: float
    stock: int


class UpdateStockRequest(BaseModel):
    stock: int


@router.post("/", summary="Add a new product")
def add_product(req: AddProductRequest):
    ok, msg = product_svc.add_product(req.product_id, req.name, req.price, req.stock)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}


@router.get("/", summary="View all products")
def get_all_products():
    return [p.to_dict() for p in product_svc.get_all_products()]


@router.get("/low-stock", summary="Products with low or zero stock")
def low_stock():
    return [p.to_dict() for p in product_svc.get_low_stock_products()]


@router.get("/{product_id}", summary="Get a single product")
def get_product(product_id: str):
    p = product_svc.get_product(product_id)
    if not p:
        raise HTTPException(404, detail="Product not found.")
    return p.to_dict()


@router.patch("/{product_id}/stock", summary="Update product stock")
def update_stock(product_id: str, req: UpdateStockRequest):
    ok, msg = product_svc.update_stock(product_id, req.stock)
    if not ok:
        raise HTTPException(400, detail=msg)
    return {"message": msg}