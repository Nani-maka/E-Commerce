from fastapi import APIRouter
from pydantic import BaseModel
from dependencies import payment_svc, logger, product_svc, cart_svc, order_svc
from services.concurrency_service import simulate_concurrent_users

router = APIRouter(prefix="/admin", tags=["Admin & Simulation"])


class FailureModeRequest(BaseModel):
    enabled: bool


class ConcurrentSimRequest(BaseModel):
    product_id:   str
    num_users:    int = 3
    quantity_each: int = 5


@router.post("/failure-mode", summary="Toggle forced payment failure injection")
def set_failure_mode(req: FailureModeRequest):
    payment_svc.set_failure_mode(req.enabled)
    return {"message": f"Failure injection {'enabled' if req.enabled else 'disabled'}."}


@router.get("/logs", summary="View all immutable audit logs")
def get_logs():
    return {"total": len(logger.get_logs()), "logs": logger.get_logs()}


@router.get("/fraud/flagged-users", summary="View users flagged for fraud")
def get_flagged_users():
    return {"flagged_users": order_svc.get_flagged_users()}


@router.post("/simulate-concurrency", summary="Simulate concurrent users grabbing same product")
def simulate(req: ConcurrentSimRequest):
    users   = [f"sim_user_{i+1}" for i in range(req.num_users)]
    results = simulate_concurrent_users(
        product_svc, cart_svc, logger,
        req.product_id, users, req.quantity_each
    )
    product = product_svc.get_product(req.product_id)
    return {
        "product_id":        req.product_id,
        "stock_before":      (product.available_stock + sum(
                                  1 for r in results.values() if r["success"]
                              ) * req.quantity_each) if product else "N/A",
        "stock_after":       product.available_stock if product else "N/A",
        "num_users":         req.num_users,
        "quantity_each":     req.quantity_each,
        "results":           results,
    }