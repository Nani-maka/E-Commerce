from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum
import time


class OrderStatus(Enum):
    CREATED = "CREATED"
    PENDING_PAYMENT = "PENDING_PAYMENT"
    PAID = "PAID"
    SHIPPED = "SHIPPED"
    DELIVERED = "DELIVERED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    RETURNED = "RETURNED"


VALID_TRANSITIONS = {
    OrderStatus.CREATED: [OrderStatus.PENDING_PAYMENT, OrderStatus.CANCELLED],
    OrderStatus.PENDING_PAYMENT: [OrderStatus.PAID, OrderStatus.FAILED, OrderStatus.CANCELLED],
    OrderStatus.PAID: [OrderStatus.SHIPPED, OrderStatus.CANCELLED],
    OrderStatus.SHIPPED: [OrderStatus.DELIVERED],
    OrderStatus.DELIVERED: [OrderStatus.RETURNED],
    OrderStatus.FAILED: [],
    OrderStatus.CANCELLED: [],
    OrderStatus.RETURNED: [],
}


@dataclass
class Product:
    product_id: str
    name: str
    price: float
    stock: int
    reserved: int = 0

    @property
    def available_stock(self) -> int:
        return self.stock - self.reserved

    def to_dict(self):
        return {
            "product_id": self.product_id,
            "name": self.name,
            "price": self.price,
            "stock": self.stock,
            "reserved": self.reserved,
            "available_stock": self.available_stock,
        }


@dataclass
class CartItem:
    product_id: str
    quantity: int
    price_at_add: float


@dataclass
class Cart:
    user_id: str
    items: Dict[str, CartItem] = field(default_factory=dict)
    coupon: Optional[str] = None

    def subtotal(self) -> float:
        return sum(item.price_at_add * item.quantity for item in self.items.values())


@dataclass
class OrderItem:
    product_id: str
    product_name: str
    quantity: int
    unit_price: float
    returned_qty: int = 0

    @property
    def total(self) -> float:
        return self.unit_price * self.quantity


@dataclass
class Order:
    order_id: str
    user_id: str
    items: List[OrderItem]
    subtotal: float
    discount: float
    total: float
    status: OrderStatus
    coupon: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    idempotency_key: Optional[str] = None

    def can_transition_to(self, new_status: OrderStatus) -> bool:
        return new_status in VALID_TRANSITIONS.get(self.status, [])